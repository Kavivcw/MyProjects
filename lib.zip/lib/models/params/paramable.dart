abstract class Encodable {
  Map<String, dynamic> toJson();
}
