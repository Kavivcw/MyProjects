import 'package:get/get.dart';

final class VMWishList extends GetxController {}
